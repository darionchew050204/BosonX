local test_patterns =
return {
{name = "test1", stages = {1}, [[
|C2|C2|C2|C2|C2|C2|C2|C2|C2|C2|
]]},
{name = "test2", stages = {1}, [[
|C2|  |  |  |  |  |  |  |  |  |
]]},
{name = "test3", stages = {1}, [[
|  |  |  |P8|  |  |  |  |  |P8|
|  |P8|  |P8|  |P8|  |  |  |P8|
|  |  |  |P8|  |  |  |  |  |P8|
]]},
{name = "test4", stages = {1}, [[
|P1|  |  |  |  |  |  |  |  |  |
|P1|  |  |  |  |  |  |  |  |  |
|P1|P1|  |  |  |  |  |  |  |  |
|  |P1|  |  |  |  |  |P2|  |  |
|  |P1|  |  |  |  |  |  |  |  |
|  |P1|P1|  |  |  |  |  |  |  |
]]},
}
