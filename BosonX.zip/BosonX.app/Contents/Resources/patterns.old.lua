-- Platform patterns.
--
-- Each row represents a lane.
-- All rows must be the same length.
-- In a row each pair of characters represents a platform piece.
-- The first character is the kind of platform:
--      P - a normal platform
--      C - a collapsing platform
--      E - an energy boost platform
--      B - a barrier (these are raised up higher than the other platforms)
-- The second character is how high the platform is.

patterns = {
    interleaved_steps = {
        "B9    P1P1P1      P3P3P3      P5P5P5      P7P7P7      E9E9E9E9E9E9",
        "P0P0P0      P2P2P2      P4P4P4      P6P6P6      P8P8P8E9E9E9E9E9E9",
        "B9    P1P1P1      P3P3P3      P5P5P5      P7P7P7      E9E9E9E9E9E9",
        "P0P0P0      P2P2P2      P4P4P4      P6P6P6      P8P8P8E9E9E9E9E9E9",
        "B9    P1P1P1      P3P3P3      P5P5P5      P7P7P7      E9E9E9E9E9E9",
        "P0P0P0      P2P2P2      P4P4P4      P6P6P6      P8P8P8E9E9E9E9E9E9",
        "B9    P1P1P1      P3P3P3      P5P5P5      P7P7P7      E9E9E9E9E9E9",
        "P0P0P0      P2P2P2      P4P4P4      P6P6P6      P8P8P8E9E9E9E9E9E9",
        "B9    P1P1P1      P3P3P3      P5P5P5      P7P7P7      E9E9E9E9E9E9",
        "P0P0P0      P2P2P2      P4P4P4      P6P6P6      P8P8P8E9E9E9E9E9E9",
    },
    rings = {
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
        "C2P2C2            C2P2C2            C2P2C2            C2P2C2      C2",
    },
    spiral = {
        "P1P1P1P1                                                    P1P1P1",
        "                                                      P1P1P1P1    ",
        "                                                P1P1P1P1          ",
        "                                          P1P1P1P1                ",
        "                                    P1P1P1P1                      ",
        "                              P1P1P1P1                            ",
        "                        P1P1P1P1                                  ",
        "                  P1P1P1P1                                        ",
        "            P1P1P1P1                                              ",
        "      P1P1P1P1                                                    ",
    },
    spiral2 = {
        "P1                  P1",
        "                  P1",
        "                P1",
        "              P1",
        "            P1",
        "          P1",
        "        P1",
        "      P1",
        "    P1",
        "  P1",
    },
}
