local particle_images = {
    square =  {intensity = 2,    scale = 8,  lateral = true,  min_plains = 4, single = true},
    blob =    {intensity = 1,  scale = 3,  lateral = true,  min_plains = 6, single = true},
    vline =   {intensity = 2,    scale = 1,  lateral = false, min_plains = 4, single = true},
    hline =   {intensity = 1.5,  scale = 4,  lateral = false, min_plains = 4, single = false},
    bars =    {intensity = 1,    scale = 3,  lateral = true,  min_plains = 4, single = true},
    box =     {intensity = 1,    scale = 3,  lateral = true,  min_plains = 4, single = true},
    triangle ={intensity = 1,   scale = 1,  lateral = true,  min_plains = 6, single = true},
    fade =    {intensity = 1,    scale = 2,  lateral = true,  min_plains = 4, single = true},
    window =  {intensity = 1,    scale = 2,  lateral = true,  min_plains = 4, single = true},
    hex =     {intensity = 1,    scale = 1.5,lateral = true , min_plains = 4, single = true},
}

if lt.form_factor == "desktop" then
    for _, p in pairs(particle_images) do
        p.intensity = p.intensity * 0.25
        p.scale = p.scale * 0.25
        p.min_plains = p.min_plains * 2
    end
else
    for _, p in pairs(particle_images) do
        p.intensity = p.intensity * 0.5
        p.scale = p.scale * 0.5
    end
end

local img_names = {}
for name, _ in pairs(particle_images) do
    table.insert(img_names, name)
end

function generate_theme(prev_theme)
    local blend = math.random() < 0.5 and "subtract" or "add"

    -- Particle image
    local img_name
    repeat
        local r = math.random(#img_names)
        img_name = img_names[math.random(#img_names)]
    until prev_theme == nil or prev_theme.particle_image ~= img_name
    --img_name = "blob"
    local img = images["particle_" .. img_name]

    -- Number of plains
    local num_plains
    repeat
        num_plains = math.random(8) + particle_images[img_name].min_plains - 1
    until prev_theme == nil or prev_theme.num_plains ~= num_plains

    -- Particle emitter width
    local emitter_width = math.random() * 10 + 5

    -- Particle size
    local start_size = (5 + math.random() * 10) * particle_images[img_name].scale
    local start_size_var = math.random() * 10
    local end_size = start_size
    local end_size_var = start_size_var

    -- Particle colors
    local start_color = {}
    local start_color_var = {}
    for c = 1, 4 do
        start_color[c] = math.random() * 0.2 + 0.45
    end
    for c = 1, 4 do
        start_color_var[c] = math.random() * 0.3
    end
    if blend == "subtract" then
        start_color[4] = start_color[4] * 0.5
        start_color_var[4] = start_color_var[4] * 0.5
    end

    -- Background gradient
    local bg_gradient = {}
    local bg_gradient_y = 0
    repeat
        local bg_color = {}
        local scale = blend == "add" and math.random() * 0.4 or 1
        for c = 1, 3 do
            bg_color[c] = (start_color[c] + math.random() * start_color_var[c] * 2 - start_color_var[c])
                * scale
        end
        table.insert(bg_gradient, {
            y = bg_gradient_y,
            color = bg_color,
        })
        local done = false
        if bg_gradient_y > 1 then
            done = true
        else 
            bg_gradient_y = bg_gradient_y + math.random() * 0.4 + 0.15
        end
    until done

    -- Ghosting effect
    local ghosting = 0--math.random() * 0.9

    -- Particle speed
    local speed = 1
    local speed_var = math.random() * 20

    -- Number of particles
    local num_particles
    local w = img.right - img.left
    local h = img.top - img.bottom
    local area = w * h * math.pow(start_size + start_size_var/2, 1.5)
    local intensity = particle_images[img_name].intensity * 
        math.pow(1 + ghosting, 2)
    num_particles = math.ceil((3500 / (area * intensity * num_plains)))

    if emitter_width == 0 then
        start_size = start_size * 2
        end_size = end_size * 2
        num_particles = math.ceil(num_particles / 4)
    end

    -- Start angle.
    local start_angle = (math.random(2) - 1) * (180 / num_plains)

    -- Lateral movement of particles.
    local lateral_movement = particle_images[img_name].lateral and math.random() < 0.2 and math.random() * 5 or 0

    -- Particle spin    
    local spin = 0
    local spin_var = 0 --math.random() < 0.3 and math.random(500) or 0

    -- Platform height
    local r = math.random(1, 4)
    local min_plat_height = r * r
    local max_plat_height = math.random(min_plat_height, math.random() < 0.5 and min_plat_height + 1 or 30)

    -- Background rotation
    local rotation_speed = (math.random() * 20 - 10) or 0
    local start_rotation = (math.random() * 180)

    local theme = {
        particle_image = img_name,
        speed = speed,
        speed_var = speed_var,
        num_plains = num_plains,
        start_angle = start_angle,
        num_particles = num_particles,
        emitter_width = emitter_width,
        lateral_movement = lateral_movement,
        start_color =       start_color,
        start_color_var =   start_color_var,
        end_color =         start_color,
        end_color_var =     start_color_var,
        start_size = start_size,
        start_size_var = start_size_var,
        end_size = start_size,
        end_size_var = end_size_var,
        spin = spin,
        spin_var = spin_var,
        blend = blend,
        ghosting = ghosting,
        bg_gradient = bg_gradient,
        rotation_speed = rotation_speed,
        start_rotation = start_rotation,
    }
    return theme
end
