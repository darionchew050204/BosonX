clearall()

local back_button = make_button1("BACK", function()
        import("title")
    end):Translate(0, button_bar_mid_y)

local reset_button = make_button1("RESET", function()
        lt.state.games_played = 0
        for s = 1, num_stages do
            lt.state.stages_played[s] = 0
        end
        import("stats")
    end):Translate(0, -0.6)

main_scene.child = lt.Layer(
    back_button,
    reset_button,
    button_bar_overlay(),
    ui_bg_overlay
)

local scene = main_scene.child

scene:Insert(lt.Text("TOTAL GAMES PLAYED: " .. lt.state.games_played, font, "center", "center")
    :Translate(0, 1.7))

for s = 1, num_stages do
    scene:Insert(lt.Text("STAGE " .. s .. " PLAYED: " ..
        lt.state.stages_played[s], font, "center", "center")
        :Translate(0, 1.7 - 0.3 * s))
end
