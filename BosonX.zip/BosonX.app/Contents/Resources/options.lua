clearall()

local back_button = make_button1("BACK", function()
        import("title")
    end):Translate(0, button_bar_mid_y)

local y = 1
local gap = 0.6

local
function tutorial_string()
    if lt.state.tutorial_complete then
        return "TUTORIAL: OFF"
    else
        return "TUTORIAL: ON  "
    end
end
local tutorial_toggle
tutorial_toggle = make_button1(tutorial_string(), function()
        lt.state.tutorial_complete = not lt.state.tutorial_complete
        tutorial_toggle.child.text(tutorial_string())
    end):Translate(0, y)

y = y - gap

local reset_button
reset_button = make_button1("RESET", function()
        reset_game()
    end):Translate(0, y)

y = y - gap

local unlock_button
unlock_button = make_button1("UNLOCK ALL", function()
        for s = 1, num_stages do
            lt.state.stage_finished[s] = true
        end
    end):Translate(0, y)

y = y - gap

main_scene.child = lt.Layer(
    tutorial_toggle,
    reset_button,
    unlock_button,
    back_button,
    button_bar_overlay(),
    ui_bg_overlay
)

if lt.form_factor == "desktop" then
    local
    function fs_string()
        if lt.IsFullScreen() then
            return "FULLSCREEN: ON"
        else
            return "FULLSCREEN: OFF  "
        end
    end
    local fs_toggle
    fs_toggle = make_button1(fs_string(), function()
            if lt.IsFullScreen() then
                lt.SetFullScreen(false)
            else
                lt.SetFullScreen(true)
            end
        end):Translate(0, y)

    y = y - gap

    main_scene.child:Insert(fs_toggle)
end

