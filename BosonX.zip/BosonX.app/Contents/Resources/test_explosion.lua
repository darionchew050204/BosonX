local wrap = lt.Wrap()
wrap.child = gen_explosion({})

main_scene.child = wrap

main_scene.child:KeyDown(function(event)
    wrap.child = gen_explosion({})
end)

