clearall()
load_game_images()

--local particles = gen_particle_trace({speed = 1.4})

    local img = images.particle_vline
    local particles = lt.ParticleSystem(img, 1000, {
            source_position_x = 0,
            source_position_y = 0,
            source_position_variance_x = 2,
            source_position_variance_y = 0,
            duration = 1.8,
            life = 1.4,
            life_variance = 0.3,
            speed = 20,
            speed_variance = 2,
            angle = 90,
            angle_variance = 10,
            start_size = 5,
            start_size_variance = 5,
            end_size = 5,
            end_size_variance = 5,
            start_spin = 0,
            start_spin_variance = 0,
            end_spin = 0,
            end_spin_variance = 0,

            start_color_red = 1,
            start_color_green = 1,
            start_color_blue = 1,
            start_color_alpha = 1,
            start_color_variance_red = 0,
            start_color_variance_green = 0,
            start_color_variance_blue = 0,
            start_color_variance_alpha = 0,
            end_color_red = 1,
            end_color_green = 1,
            end_color_blue = 1,
            end_color_alpha = 0,
            end_color_variance_red = 1,
            end_color_variance_green = 1,
            end_color_variance_blue = 1,
            end_color_variance_alpha = 0,
        })
main_scene.child = particles:Scale(0.1):Translate(0, -2)

main_scene.child:KeyDown(function()
    import "test"
end)
main_scene.child:PointerDown(function()
    import "test"
end)
