function make_default_backpack()
    local notch_layer = lt.Layer()
    local scale = notch_layer:Scale(1)
    local mirror_notches = {}
    local notches = {}
    local num_notches = 0
    local inner_glow_enabled = false
    local ring_enabled = false
    local inner_glow = images.default_backpack_mid:Scale(0)
    local ring = images.default_backpack_ring:Scale(0)
    local layer = lt.Layer()
    local backpack_track = back_hum_track()
    layer:Insert(scale)
    layer:Insert(backpack_track)
    local maxed_out_energy = 1
    local prev_energy = 0
    local in_hover_mode = false

    local
    function notch_action(i)
        local
        function action()
            local angle = (math.random() - 0.5) * 360
            notches[i]:Tween{angle = angle, time = 0.5, action = action}
        end
        return action
    end

    local
    function hover_notch_action(i, angle, omega)
        local
        function action()
            notches[i].angle = angle
            notches[i]:Tween{angle = angle + omega, time = 0.1, action = action}
        end
        return action
    end

    local
    function new_notch(i)
        local angle = 60 * i
        local notch = images.default_backpack_notch:Rotate(angle)
        local mirror = notch:Scale(-1, 1)
        notches[i] = notch
        mirror_notches[i] = mirror
        notch_action(i)()
    end

    local
    function set_notches(n)
        if n < num_notches then
            for i = n + 1, num_notches do
                notch_layer:Remove(notches[i])
                notch_layer:Remove(mirror_notches[i])
            end
            num_notches = n
        elseif n > num_notches then
            for i = num_notches + 1, n do
                if not notches[i] then
                    new_notch(i)
                end
                notch_layer:Insert(notches[i])
                notch_layer:Insert(mirror_notches[i])
            end
            num_notches = n
        end
    end

    local
    function enable_inner_glow()
        if not inner_glow_enabled then
            layer:Insert(inner_glow)
            inner_glow.scale = 0
            inner_glow:Tween{scale = 1, time = 0.5}
            inner_glow_enabled = true
        end
    end

    local
    function disable_inner_glow()
        if inner_glow_enabled then
            layer:Remove(inner_glow)
            inner_glow_enabled = false
        end
    end

    local
    function enable_ring()
        --[[
        if not ring_enabled then
            ring.scale = 0
            notch_layer:Insert(ring)
            ring:Tween{scale = 1, time = 0.5}
            ring_enabled = true
        end
        ]]
    end

    local
    function disable_ring()
        if ring_enabled then
            notch_layer:Remove(ring)
            ring_enabled = false
        end
    end

    local
    function set_energy(energy)
        local ring_threshold = 0.01
        if energy == prev_energy then
            return
        end
        prev_energy = energy
        local c = math.min(1, energy / maxed_out_energy)
        if c == 0 then
            disable_inner_glow()
        else
            enable_inner_glow()
        end
        if c < ring_threshold then
            disable_ring()
        else
            enable_ring()
        end
        set_notches(math.max(0, math.floor((c - ring_threshold) * 17)))
    end

    local
    function set_hover(hover)
        if hover then
            if not in_hover_mode then
                local omega = num_notches > 0 and 360 / num_notches or 0
                scale:Tween{scale = 1.2, time = 0.3, easing = "in"}
                for i, notch in ipairs(notches) do
                    local angle = (omega * i) % 360
                    notch:Tween{angle = angle, time = 0.3, easing = "in",
                        action = hover_notch_action(i, angle, omega)}
                    if i <= num_notches then
                        notch_layer:Remove(mirror_notches[i])
                    end
                end
                in_hover_mode = true
                if num_notches > 0 then
                    local gain = (math.min(10, num_notches) / 10) * 0.7+ 0.3
                    backpack_track.gain = 0
                    backpack_track:Play()
                    backpack_track:Tween{gain = gain * lt.state.sfx_volume, time = 0.3}
                end
            end
        else
            if in_hover_mode then
                scale:Tween{scale = 1, time = 0.3, easing = "in"}
                for i = 1, #notches do
                    notch_action(i)()
                    if i <= num_notches then
                        notch_layer:Insert(mirror_notches[i])
                    end
                end
                in_hover_mode = false
                backpack_track:Tween{gain = 0, time = 0.3, action = function()
                    backpack_track:Pause()
                end}
            end
        end
    end

    return {
        node = layer,
        set_energy = set_energy,
        set_hover = set_hover,
    }
end
