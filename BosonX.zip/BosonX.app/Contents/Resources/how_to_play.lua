clearall()

main_scene.child = lt.Layer()
local bg = images.title_bg:Mesh():Grid(1, 30)
    :Stretch(-1.5, 0, 0, 2, 0, 0, 0, 0, 0)
    :Stretch(1.5, 0, 0, 0, 2, 0, 0, 0, 0)
    :Shift(0, 0.5, 0)
    :Scale(1)
main_scene.child:Insert(bg)
main_scene.child:Insert(lt.Rect(lt.left, lt.bottom, lt.right, lt.top):Tint(0, 0, 0, 0.5))

if lt.form_factor == "desktop" then
    main_scene.child:Insert(images.how_to_play_keys)
else
    main_scene.child:Insert(images.how_to_play_wide)
end

local function begin()
    import "stage_select"
end
main_scene.child:KeyDown(begin)
main_scene.child:PointerDown(begin)
