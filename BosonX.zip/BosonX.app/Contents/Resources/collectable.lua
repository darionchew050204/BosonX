local collectable_registry = {
    --{create = make_artifact_gate},
    --{create = make_rune},
    --{create = make_prism},
}

local num_collectables = #collectable_registry

local
function add_collectables_for_row(level, row)
    for _, collectable in ipairs(collectable_registry) do
        collectable.create(level, row)
    end
end

function add_back_row_collectables(level)
    add_collectables_for_row(level, level.back_row)
end

function remove_front_collectables(level)
    for lane = 1, level.num_lanes do
        local collectable = level.collectables[lane][level.front_row]
        if collectable and collectable.node then
            level.collectables_layer:Remove(collectable.node)
        end
        level.collectables[lane][level.front_row] = nil
    end
end

local
function collect(level)
    local player = level.player
    local lane = player.lane
    if lane < 1 or lane > level.num_lanes then
        return
    end
    local collectable = level.collectables[lane][level.front_row]
    if collectable then
        if not collectable.collected then
            if collectable.y > player.y - 0.5 and collectable.y < player.y + man_height + 0.5 then
                local effect = collectable.effect
                if effect then
                    effect(collectable, level, player)
                end
                collectable.collected = true
            end
        end
    end
end

function generate_collectables(level)
    local collectables = {}
    for lane = 1, level.num_lanes do
        collectables[lane] = {}
    end
    level.collectables = collectables
    for row = 10, level.back_row do
        add_collectables_for_row(level, row)
    end
    level.collect = collect
end
