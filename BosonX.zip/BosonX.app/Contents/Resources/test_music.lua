samples = lt.LoadSamples{
    "cheerful_trance",
    "bassdrum",
    "bass",
    "cymbal",
    "highnote",
}

main_scene = lt.Wrap(lt.Layer())
main_scene:Activate()

function lt.Render()
    main_scene:Draw()
end

function lt.Advance(dt)
    lt.ExecuteActions(dt)
end

import "ltmusic"

main_scene.child = import("music")
--main_scene:Tween{action_speed = 1.5, time = 20}

