-- square scan

local sscan_particles_target = lt.RenderTarget(nil, 16, 16, -1, -1, 1, 1,
    -config.platform_width_scale/2, -1, config.platform_width_scale/2, 1,
    "nearest", "nearest")
local sparticles = lt.ParticleSystem(images.particle_box, 50, {
    source_position_x = 0,
    source_position_y = 0,
    source_position_variance_x = 1,
    source_position_variance_y = 1,
    life = 1.0,
    life_variance = 0,
    speed = 0,
    speed_variance = 1,
    angle = 0,
    angle_variance = 360,
    start_size = 1,
    start_size_variance = 1,
    end_size = 3,
    end_size_variance = 1,
    start_color_red = 1,
    start_color_green = 0.6,
    start_color_blue = 0.6,
    start_color_alpha = 0.8,
    start_color_variance_red = 0,
    start_color_variance_green = 0,
    start_color_variance_blue = 0,
    start_color_variance_alpha = 0,
    end_color_red = 1,
    end_color_green = 0.0,
    end_color_blue = 0.0,
    end_color_alpha = 0.5,
    end_color_variance_red = 0,
    end_color_variance_green = 0,
    end_color_variance_blue = 0,
    end_color_variance_alpha = 0,
})
local sparticles_blend = sparticles:BlendMode("add")
for i = 1, 180 do
    sparticles:Advance(1/60)
end

-- horizontal scan

local w = 33
local hscan_particles_target = lt.RenderTarget(nil, 256, 8, -w, -0.5, w, 0.5,
    -w, -0.5, w, 0.5,
    "nearest", "nearest")
local hparticles = lt.ParticleSystem(images.particle_square, 150, {
    source_position_x = -w,
    source_position_y = 0,
    source_position_variance_x = 0,
    source_position_variance_y = 0.5,
    life = 3.0,
    life_variance = 0.1,
    speed = 20,
    speed_variance = 10,
    angle = 0,
    angle_variance = 0,
    start_size = 15,
    start_size_variance = 0,
    end_size = 2,
    end_size_variance = 0,
    start_color_red = 1,
    start_color_green = 0.4,
    start_color_blue = 0.4,
    start_color_alpha = 1,
    start_color_variance_red = 0,
    start_color_variance_green = 0,
    start_color_variance_blue = 0,
    start_color_variance_alpha = 1,
    end_color_red = 1,
    end_color_green = 0.0,
    end_color_blue = 0.0,
    end_color_alpha = 1,
    end_color_variance_red = 0,
    end_color_variance_green = 0,
    end_color_variance_blue = 0,
    end_color_variance_alpha = 1,
})
local hparticles_blend = hparticles:BlendMode("add")
local hparticles_scale = hparticles_blend:Scale(-1, 1)
for i = 1, 180 do
    hparticles:Advance(1/60)
end

-- vertical scan

local h = 50
local w = config.platform_width_scale / 2
local vscan_particles_target = lt.RenderTarget(nil, 8, 256, -w, -h * 2, w, h,
    -w, -h * 2, w, h,
    "nearest", "nearest")
local vparticles = lt.ParticleSystem(images.particle_box, 200, {
    source_position_x = 0,
    source_position_y = h + 4,
    source_position_variance_x = w,
    source_position_variance_y = 0,
    life = 2.4,
    life_variance = 0.5,
    speed = 50,
    speed_variance = 10,
    angle = -90,
    angle_variance = 0,
    start_size = 10,
    start_size_variance = 5,
    end_size = 1,
    end_size_variance = 0,
    start_color_red = 1,
    start_color_green = 0.4,
    start_color_blue = 0.4,
    start_color_alpha = 1,
    start_color_variance_red = 0,
    start_color_variance_green = 0,
    start_color_variance_blue = 0,
    start_color_variance_alpha = 1,
    end_color_red = 1,
    end_color_green = 0.0,
    end_color_blue = 0.0,
    end_color_alpha = 1,
    end_color_variance_red = 0,
    end_color_variance_green = 0,
    end_color_variance_blue = 0,
    end_color_variance_alpha = 1,
})
local vparticles_blend = vparticles:BlendMode("add")
for i = 1, 180 do
    vparticles:Advance(1/60)
end

local t_accum = 0
local
function advance(dt)
    t_accum = t_accum + dt
    if t_accum > 2/60 then
        sparticles:Advance(t_accum)
        sparticles_blend:Draw(sscan_particles_target, 0.2, 0, 0, 1)
        hparticles:Advance(t_accum)
        hparticles_blend:Draw(hscan_particles_target, 0.2, 0, 0, 1)
        hparticles_scale:Draw(hscan_particles_target)
        vparticles:Advance(t_accum)
        vparticles_blend:Draw(vscan_particles_target, 0.2, 0, 0, 1)
        t_accum = 0
    end
end

return {
    sscan_particles = sscan_particles_target,
    hscan_particles = hscan_particles_target,
    vscan_particles = vscan_particles_target,
    advance = advance,
}
