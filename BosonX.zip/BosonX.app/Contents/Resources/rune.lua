local r = 0.4
local tr, tg, tb, ta = 0, 0.5, 0.7, 0.2
local br, bg, bb, ba = 0, 0.4, 0.6, 0.2
local nr, ng, nb, na = 0, 0.1, 0.3, 0.2
local fr, fg, fb, fa = 0, 0.5, 0.3, 0.2
local lr, lg, lb, la = 0, 0.4, 0.7, 0.2
local rr, rg, rb, ra = 0, 0.6, 0.8, 0.2
local cube_vec = lt.Vector({
    -- top
    {-r, r, r, tr, tg, tb, ta},
    { r, r, r, tr, tg, tb, 1},
    { r, r,-r, tr, tg, tb, ta},
    { r, r,-r, tr, tg, tb, ta},
    {-r, r,-r, tr, tg, tb, ta},
    {-r, r, r, tr, tg, tb, ta},
    -- bottom
    {-r,-r, r, br, bg, bb, ba},
    { r,-r, r, br, bg, bb, 1},
    { r,-r,-r, br, bg, bb, ba},
    { r,-r,-r, br, bg, bb, ba},
    {-r,-r,-r, br, bg, bb, ba},
    {-r,-r, r, br, bg, bb, ba},
    -- left
    {-r, r, r, lr, lg, lb, la},
    {-r,-r, r, lr, lg, lb, 1},
    {-r,-r,-r, lr, lg, lb, la},
    {-r,-r,-r, lr, lg, lb, la},
    {-r, r,-r, lr, lg, lb, la},
    {-r, r, r, lr, lg, lb, la},
    -- right
    { r, r, r, rr, rg, rb, ra},
    { r,-r, r, rr, rg, rb, 1},
    { r,-r,-r, rr, rg, rb, ra},
    { r,-r,-r, rr, rg, rb, ra},
    { r, r,-r, rr, rg, rb, ra},
    { r, r, r, rr, rg, rb, ra},
    -- near
    {-r, r, r, nr, ng, nb, na},
    { r, r, r, nr, ng, nb, 1},
    { r,-r, r, nr, ng, nb, na},
    { r,-r, r, nr, ng, nb, na},
    {-r,-r, r, nr, ng, nb, na},
    {-r, r, r, nr, ng, nb, na},
    -- far
    {-r, r,-r, fr, fg, fb, fa},
    { r, r,-r, fr, fg, fb, 1},
    { r,-r,-r, fr, fg, fb, fa},
    { r,-r,-r, fr, fg, fb, fa},
    {-r,-r,-r, fr, fg, fb, fa},
    {-r, r,-r, fr, fg, fb, fa},
})
local cube = lt.DrawVector(cube_vec, "triangles", 3, 4)

function make_rune_node(row, lane, y, artifact_type)
    local node1 = cube:BlendMode("add"):Rotate(0)
    local node2 = node1:Pitch(0)
    local
    function tween1()
        node1.angle = 0
        node1:Tween{angle = 360, time = 4.3, action = tween1}
    end
    local
    function tween2()
        node2.pitch = 0
        node2:Tween{pitch = 360, time = 6, action = tween2}
    end
    tween1()
    tween2()
    local rune = images[artifact_type .. "_rune"]:Translate(0, -0.1)
    local tween3, tween4
    function tween3()
        rune:Tween{y = 0.1, time = 1, easing = "revolve", action = tween4}
    end
    function tween4()
        rune:Tween{y = -0.1, time = 1, easing = "revolve", action = tween3}
    end
    tween3()
    local node = lt.Layer(rune, node2):Scale(2)
        :Translate(lane * config.platform_width_scale, y, -row * config.platform_depth_scale)
    return node
end

local
function rune_effect(artifact_id)
    return function(collectable, level, player)
        local overlay = lt.Rect(lt.left, lt.bottom, lt.right, lt.top):BlendMode("add"):Tint(0.1, 1, 1, 1)
        level.background_layer:Insert(overlay)
        overlay:Tween{alpha = 0, time = 1, action = function()
            level.background_layer:Remove(overlay)
        end}

        play_collect()
        level.collectables_layer:Remove(collectable.node)
        collectable.node = nil
        lt.state.artifact_active[artifact_id] = true
        lt.state.last_unlocked_artifact = artifact_id
    end
end

function make_rune(level, row)
    if #level.stage.allowed_runes == 0 then
        return
    end
    local artifact_id = level.stage.allowed_runes[math.random(#level.stage.allowed_runes)]
    if lt.state.artifact_active[artifact_id] then
        return
    end
    local artifact_type = artifact_registry[artifact_id]
    artifact_type.rune(level, row, rune_effect(artifact_id))
end
