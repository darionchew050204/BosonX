local
function make_portal_key_node(row, lane, y)
    local node = images.portal_key:Scale(10):Tint(1, 1, 1, 0)
        :Translate(lane * config.platform_width_scale, y, -row * config.platform_depth_scale)
    node:Tween{alpha = 1, time = 0.5, action = function()
        node.child = node.child.child
    end}
    return node
end

local
function portal_key_effect(collectable, level)
    play_collect()
    level.collectables_layer:Remove(collectable.node)
    collectable.node = nil
    level.collected_portal_keys_layer:Insert(
        images.portal_key:Translate(lt.left + 0.3, lt.top - 0.3 - level.num_keys_collected * 0.3))
    level.num_keys_collected = level.num_keys_collected + 1
end

function make_portal_key(level, row, lane)
    local highest = level:get_highest_platform(row)
    local y = highest.y + 6
    local node = make_portal_key_node(row, lane, y)
    level.collectables[lane][row] = {
        node = node,
        effect = portal_key_effect,
        y = y,
    }
    level.collectables_layer:InsertBack(node)
end
