-- C C# D D# E F F# G G# A A# B
-- + up octave
-- - down octave
-- _ rest

local semitone = 1.059463094359295
local notes = {1/32}
for i = 2, 12 * 12 do
    notes[i] = notes[i - 1] * semitone
end

local note_offset = {
    ["C"] = 0,
    ["C#"] = 1,
    ["D"] = 2,
    ["D#"] = 3,
    ["E"] = 4,
    ["F"] = 5,
    ["F#"] = 6,
    ["G"] = 7,
    ["G#"] = 8,
    ["A"] = 9,
    ["A#"] = 10,
    ["B"] = 11,
}

local
function parse_music(info)
    local str = info.score
    local tempo = info.tempo or 120
    local loop = info.loop_sample or false
    local base = 61 -- notes[61] == 1.0
    local beat = (60 / (tempo)) / 8
    local instrs = {}
    local release = info.release or 0
    local attack = info.attack or 0
    local gain = info.gain or 1
    local callback = info.callback
    local marker = 1
    local n = 1
    for instr_str in str:gmatch("%S+") do
        local instr
        local note, duration = instr_str:match("([A-G]#?)([0-9]+)")
        if note then
            duration = tonumber(duration)
            local pitch = notes[base + note_offset[note]]
            instr = function(track)
                local t = beat * duration
                track.pitch = pitch
                track:Tween{gain = gain, time = attack, easing="zoomout"}
                if not loop then
                    track:Rewind()
                end
                if callback then
                    callback()
                end
                return t
            end
        else
            local rest = instr_str:match("%_([0-9]+)")
            if rest then
                rest = tonumber(rest)
                instr = function(track)
                    local t = beat * rest
                    track:Tween{gain = 0.0, time = release, easing="zoomout"}
                    return t
                end
            else
                local dup = instr_str:match("x([0-9]+)")
                if dup then
                    dup = tonumber(dup) - 1
                    for i = 1, dup do
                        for j = marker, n do
                            table.insert(instrs, instrs[j])
                        end
                    end
                    n = #instrs
                elseif instr_str == "|" then
                    marker = n + 1
                elseif instr_str == "+" then
                    base = base + 12
                elseif instr_str == "-" then
                    base = base - 12
                end
            end
        end
        if instr then
            table.insert(instrs, instr)
            n = #instrs
        end
    end
    return instrs
end

function lt.Music(info)
    local sample = info.sample
    local music_str = info.score
    local loop = info.loop_sample or false
    local tempo = info.tempo or 120
    local instructions = parse_music(info)
    local track = lt.Track()
    track.gain = info.gain or 1
    track:Queue(sample)
    track:SetLoop(loop)
    track:Play()
    local ip = 1
    local max_ip = #instructions
    local
    function action(dt, track)
        local delay = instructions[ip](track)
        ip = ip + 1
        if ip > max_ip then
            ip = 1
        end
        return delay
    end
    track:Action(action)
    return track
end
