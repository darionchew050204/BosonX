local start_energy = ...
local curr_energy = start_energy
local y = 1.6
local h = 0.02
local x = -2.8
local w = 4
local os = 0.01
local r1, g1, b1 = 0, 1, 1
local r2, g2, b2 = 1, 1, 1
local energy_bar = 
    lt.DrawVector(lt.Vector({
        {os, -os,      0, 0, 0, 1},
        {w+os, -os,    0, 0, 0, 1},
        {w+os, h-os,  0, 0, 0, 1},
        {w+os, h-os,  0, 0, 0, 1},
        {os, h-os,    0, 0, 0, 1},
        {os, -os,      0, 0, 0, 1},
        {2*os, -2*os,      0, 0, 0, 0.2},
        {w+2*os, -2*os,    0, 0, 0, 0.2},
        {w+2*os, h-2*os,  0, 0, 0, 0.2},
        {w+2*os, h-2*os,  0, 0, 0, 0.2},
        {2*os, h-2*os,    0, 0, 0, 0.2},
        {2*os, -2*os,      0, 0, 0, 0.2},

        {0, 0,      r1, g1, b1, 1},
        {w, 0,      r2, g2, b2, 1},
        {w, h,      r2, g2, b2, 1},
        {w, h,      r2, g2, b2, 1},
        {0, h,      r1, g1, b1, 1},
        {0, 0,      r1, g1, b1, 1},
    }), "triangles", 2, 3):Scale(start_energy, 1):Translate(x, y)

local
function sync_energy_bar(energy)
    if energy == curr_energy then
        return
    end
    local ease = "linear"
    local time = 0.5
    energy_bar.child.scale_x = curr_energy
    energy_bar.child:Tween{scale_x = energy, time = time, easing = ease}
    curr_energy = energy
end

energy_bar.sync = sync_energy_bar
sync_energy_bar(start_energy)

return energy_bar
