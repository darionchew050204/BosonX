local models = lt.LoadModels{"monkey"}

local model1 = models.monkey:Rotate(0):Pitch(0):Translate(0, 0, -1):Material{
    specular_red = 0,
    specular_green = 0.9,
    specular_blue = 1,
    ambient_red = 0,
    ambient_green = 0,
    ambient_blue = 1,
    diffuse_red = 0,
    diffuse_green = 0.1,
    diffuse_blue = 1,
    shininess = 10,
}
local model2 = models.monkey:Rotate(0):Pitch(0):Translate(0, 0, -1):Material{
    specular_red = 1,
    specular_green = 0.9,
    specular_blue = 0,
    ambient_red = 1,
    ambient_green = 0,
    ambient_blue = 0,
    diffuse_red = 1,
    diffuse_green = 0.1,
    diffuse_blue = 0,
    shininess = 10,
}
local model = lt.Layer(model1, model2:Translate(1, 0))
local function spin()
    model1:Tween{
        pitch = model1.pitch + 90,
        angle = model1.angle + 70,
        time = 1,
        action = spin}
end
spin()

local scene = lt.Layer()

local light = model:Light()

--scene:Insert(lt.Rect(-2, -2, 2, 2):Tint(0.5, 1, 1))
scene:Insert(light:Lighting():DepthTest():Perspective(1, 10, 20))

main_scene.child = scene
