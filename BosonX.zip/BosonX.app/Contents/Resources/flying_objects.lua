--[[
local flying_objects_layer = lt.Layer()
local
function add_flying_object()
    local flying_object = images.flying_object:Scale(0):Translate(0, 0):Rotate(0)
    local
    function tween()
        local final_scale = 4
        local time = 100 / flying_object_speed
        local max_distance = 20
        local min_distance = 10
        local distance = math.random() * (max_distance - min_distance) + min_distance;
        local angle = math.random() * 360
        flying_object.x = 0
        flying_object.angle = angle
        flying_object.scale = 0
        flying_object:Tween{
            x = 0,
            delay = r() * time,
            action = function()
                flying_objects_layer:Remove(flying_object)
                flying_objects_layer:InsertBack(flying_object)
                flying_object:Tween{
                    scale = final_scale,
                    x = distance,
                    easing = "zoomin",
                    time = time,
                    action = tween
                }
            end
        }
    end
    tween()
    flying_objects_layer:Insert(flying_object)
end
for i = 1, num_flying_objects do
    add_flying_object()
end
flying_objects_layer = flying_objects_layer:Translate(0, portal_y_offset)
]]

