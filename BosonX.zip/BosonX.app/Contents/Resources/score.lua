function record_new_score(score, stage)
    local prev_best = lt.state.best_score[stage] or 0
    if not prev_best or prev_best < score then
        lt.state.best_score[stage] = score
    end

    table.insert(lt.state.score_history[stage], score)
    if #lt.state.score_history[stage] > config.score_history_size then
        table.remove(lt.state.score_history[stage], 1)
    end

    return prev_best
end
