local sound = lt.Track()
sound:Queue(samples.step1)
sound:Queue(samples.breath1)
sound:Queue(samples.heartbeat)
sound:Play()

local paused = true
local empty = lt.Layer()

main_scene.child = empty

function lt.KeyDown()
    if paused then
        main_scene.child = sound
        paused = false
    else
        main_scene.child = empty
        paused = true
    end
end
