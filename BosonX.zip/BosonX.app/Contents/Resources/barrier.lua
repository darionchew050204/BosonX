local
function build_barrier()
--[[
    if not barrier then
        --barrier = models.platform2:Clone():Stretch(0, 0, 0, 30, -1, 30, 30, 0, 0)
        barrier = models.barrier:Clone():Stretch(-2, 0, 0, 3, 0, 0, 0, 0, 0):Scale(33)
    end
    return barrier
]]
    local width = 23
    local height = 33
    local depth = 2
    local base = models.platform2
    local bar_w = 10
    local bar_h = 33
    local node = base:Clone():Stretch(0, 0, 0, bar_w-1, -1, bar_h-1, bar_h-1, depth-1, -1)
    for i = 1, 20 do
        local piece = base:Clone()
        local left = math.random() * width * 0.15 + 0.1 * width
        local right = math.random() * (width - left) * 0.15
        local up = math.random() * height * 0.5
        local down = math.random() * (height - up)
        local out = math.random() * 2
        piece:Stretch(0, 0, 0, left - 1, right - 1, down - 1, up - 1, out, out)
        local x = math.random() * (width - left - right) + right
        local y = math.random() * (height * 2 - up - down)
        piece:Shift(-x, height - y, 0)
        if not node then
            node = piece
        else
            node:Merge(piece)
        end
    end
    return node
end

local
function build_left_barrier()
    local width = 23
    local height = 33
    local depth = 2
    local base = models.platform2
    local bar_w = 10
    local bar_h = 33
    local node = base:Clone():Stretch(0, 0, 0, bar_w-1, -1, bar_h-1, bar_h-1, depth-1, -1)
    return node
end

local
function build_right_barrier()
    local width = 23
    local height = 33
    local depth = 2
    local base = models.platform2
    local bar_w = 10
    local bar_h = 33
    local node = base:Clone():Stretch(0, 0, 0, -1, bar_w-1, bar_h-1, bar_h-1, depth-1, -1)
    return node
end

local
function insert_barrier(level, row, lane, left_lane, right_lane, x_left, x_right, y)
    local player = level.player
    local z = -row * config.platform_depth_scale
    local model = build_barrier()
    local left_barrier = model
        --:Scale(25, 25, 25)
        :Translate(-100, y, z)
        :Tween{x = x_left, time = 0.2, easing = "decel"}
--    local left_barrier_core = models.barrier2
--        :Scale(25, 25, 25)
--        :Translate(-100, y, z)
--        :Tween{x = x_left, time = 0.3, easing = "decel"}
    local right_barrier = model
        :Scale(-1, 1)
        :Translate(100, y, z)
        :Tween{x = x_right, time = 0.2, easing = "decel"}
--    local right_barrier_core = models.barrier2
--        :Scale(-25, -25, 25)
--        :Translate(100, y, z)
--        :Tween{x = x_right, time = 0.3, easing = "decel"}
    local angle = (lane - 1) * level.lane_rotate
    local barriers = lt.Layer(left_barrier, right_barrier)
        :Rotate(angle, 0, config.level_center_y)
--    local barrier_cores = lt.Layer(left_barrier_core, right_barrier_core)

    local checked = false
    barriers:Action(function(dt)
        local prev_z = level.z - level.speed
        local barrier_z = left_barrier.z
        if -barrier_z < (level.z + 2) and not checked and not player.dead then
            local p_angle = player.angle
            local min_angle = (left_lane - 1 + 0.5) * level.lane_rotate 
            local max_angle = (right_lane - 1 - 0.5) * level.lane_rotate
            if p_angle < min_angle or p_angle > max_angle then
                player.die("hitwall")
            end
            checked = true
        end
        if -barrier_z < level.z - 4 then
            level.barrier_layer:Remove(barriers)
            --level.glowing_layer:Remove(barrier_cores)
        end
    end)
    level.barrier_layer:Insert(barriers)
    --level.glowing_layer:Insert(barrier_cores)
end

function add_left_barrier(level, row, lane)
    local player = level.player
    if not player then
        return
    end
    local z = -row * config.platform_depth_scale
    local model = build_left_barrier()
    local x = config.platform_width_scale * 0.5
    local left_barrier = model
        :Translate(-100, 0, z)
        :Tween{x = x, time = 0.2, easing = "decel"}
    local angle = (lane - 1) * level.lane_rotate
    local barrier = left_barrier
        :Rotate(angle, 0, config.level_center_y)

    local checked = false
    barrier:Action(function(dt)
        local prev_z = level.z - level.speed
        local barrier_z = left_barrier.z
        if -barrier_z < (level.z + 2) and not checked and not player.dead then
            if player.lane == lane then -- XXX incorrect
                player.die("hitwall")
            end
            checked = true
        end
        if -barrier_z < level.z - 4 then
            level.barrier_layer:Remove(barrier)
        end
    end)
    level.barrier_layer:Insert(barrier)
end

function add_right_barrier(level, row, lane)
    local player = level.player
    if not player then
        return
    end
    local z = -row * config.platform_depth_scale
    local model = build_right_barrier()
    local x = -config.platform_width_scale * 0.5
    local right_barrier = model
        :Translate(100, 0, z)
        :Tween{x = x, time = 0.2, easing = "decel"}
    local angle = (lane - 1) * level.lane_rotate
    local barrier = right_barrier
        :Rotate(angle, 0, config.level_center_y)

    local checked = false
    barrier:Action(function(dt)
        local prev_z = level.z - level.speed
        local barrier_z = right_barrier.z
        if -barrier_z < (level.z + 2) and not checked and not player.dead then
            if player.lane == lane then -- XXX incorrect, should be inequality
                player.die("hitwall")
            end
            checked = true
        end
        if -barrier_z < level.z - 4 then
            level.barrier_layer:Remove(barrier)
        end
    end)
    level.barrier_layer:Insert(barrier)
end

function add_barrier(level, n)
    n = n or 1
    local row = level.back_row
    for _, path in ipairs(level.paths) do
        local platform = path[row]
        if platform then
            local left_lane = platform.lane - 1
            local right_lane = platform.lane + 1
            local x_left = -config.platform_width_scale * 0.5
            local x_right = config.platform_width_scale * 0.5
            if platform.is_gap then
                -- must leave enough room for player to jump to next platform,
                -- which may be one lane to the left or right of the gap
                x_left = x_left - config.platform_width_scale
                x_right = x_right + config.platform_width_scale
                left_lane = left_lane - 1
                right_lane = right_lane + 1
            end
            insert_barrier(level, row, platform.lane, left_lane, right_lane, x_left, x_right, platform.y)
            local gain = 1 / n
            samples.barrier_close:Play(math.random() * 0.1 + 0.95, gain * lt.state.sfx_volume)
            return
        end
    end
end
