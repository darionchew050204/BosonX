clearall()

load_game_images()

log("here")
local particles = import "scan_particles"

function lt.Advance(dt)
    particles.advance(dt)
end

function lt.Render()
    particles.vscan_particles:Scale(2/config.platform_width_scale, 1):Scale(0.02):Draw()
end
