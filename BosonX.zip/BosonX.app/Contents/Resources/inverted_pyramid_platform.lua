local
function make_pyr_platform_node(x, y, z, length, height, width)
    local l, r = x - width/2, x + width/2 -- left, right
    local t, b = y, y - height            -- top, bottom
    local n, f = z, z - length            -- near, far
    local mx, mz = (r - l) / 2 + l, (n - f) / 2 + f -- mid z, mid z
    local t_r, t_g, t_b, t_a = 0.9, 0.9, 0.1, 0.8
    local b_r, b_g, b_b, b_a = 1.0, 0.0, 0.0, 0.8
    local l_r, l_g, l_b, l_a = 0.9, 0.9, 0.1, 0.5
    local r_r, r_g, r_b, r_a = 0.9, 0.9, 0.1, 0.5
    local n_r, n_g, n_b, n_a = 0.9, 0.9, 0.1, 0.7
    local f_r, f_g, f_b, f_a = 0.9, 0.9, 0.1, 0.5
    local vec = lt.Vector({
        -- top face
        {l, t, n, t_r, t_g, t_b, t_a},
        {l, t, f, t_r, t_g, t_b, t_a},
        {r, t, f, t_r, t_g, t_b, t_a},
        {l, t, n, t_r, t_g, t_b, t_a},
        {r, t, n, t_r, t_g, t_b, t_a},
        {r, t, f, t_r, t_g, t_b, t_a},
        -- far face
        {l, t, f, f_r, f_g, f_b, f_a},
        {r, t, f, f_r, f_g, f_b, f_a},
        {mx, b, mz, b_r, b_g, b_b, b_a},
        -- near face
        {l, t, n, n_r, n_g, n_b, n_a},
        {r, t, n, n_r, n_g, n_b, n_a},
        {mx, b, mz, b_r, b_g, b_b, b_a},
        -- left face
        {l, t, n, l_r, l_g, l_b, l_a},
        {l, t, f, l_r, l_g, l_b, l_a},
        {mx, b, mz, b_r, b_g, b_b, b_a},
        -- right face
        {r, t, n, r_r, r_g, r_b, r_a},
        {r, t, f, r_r, r_g, r_b, r_a},
        {mx, b, mz, b_r, b_g, b_b, b_a},
    })
    local node = lt.DrawVector(vec, "triangles", 3, 4)
    return node
end

local
function build_inverted_pyramid_platform(path, lane, row, y, length, height, width)
    local node = make_pyr_platform_node(lane, y, -row, length, height, width)
    path[row] = {
        platform_type = "solid",
        lane = lane,
        length = length,
        start_row = row,
        end_row = row + length - 1,
        y = y,
        normal_node = node,
    }
end

function build_random_inverted_pyramid_platform(level, path, row, prev, y, lane)
    local height = 6
    local length = math.random(config.platform_min_length, config.platform_max_length)
    local width = math.random() * 0.5 + 0.5
    build_inverted_pyramid_platform(path, lane, row, y, length, height, width)
    return true
end
