local prop_sets = {
    {
        models = {
            "circle_arch1",
            "circle_arch2",
            "circle_arch3",
            "circle_arch4",
        },
        num_objs = {20, 30},
        delay = {0.2, 0.5},
        angle = 45,
        angle2 = 45,
    },
    {
        models = {
            "square_arch1",
            "square_arch2",
            "square_arch3",
        },
        num_objs = {20, 30},
        delay = {0.2, 0.5},
        angle = 90,
        angle2 = 0,
    },
    {
        models = {
            "hex_arch1",
            "hex_arch2",
        },
        num_objs = {7, 12},
        delay = {0.2, 0.5},
        angle = 60,
        angle2 = 0,
    },
}

local
function add_prop(set, level)
    local z1 = -level.z - 800
    local x = 0 --level.num_lanes * 0.5 * config.platform_width_scale
    local y = config.level_center_y --level.gradient * level.back_row
    local scale_x = 50 + math.random(5)
    local scale_y = scale_x
    if math.random(2) == 1 then
        scale_x = -scale_x
    end
    if math.random(2) == 1 then
        scale_y = -scale_y
    end
    local initial_angle = 0
    if set.angle ~= 0 then
        initial_angle = set.angle * math.random(math.ceil(360 / set.angle))
    end
    local prop = models[set.models[math.random(#set.models)]]:Scale(0, 0, 1000)
    if set.angle2 ~= 0 or initial_angle ~= 0 then
        prop = prop:Rotate(initial_angle)
    end
    prop = prop:Translate(x, y, z1)
    prop:Tween{scale_x = scale_x, scale_y = scale_y, time = 0.5, easing = "zoomout"}
    prop:Tween{scale_z = math.abs(scale_x), time = 0.5, delay = 0.1, easing = "zoomout"}
    prop:Action(function(dt)
        if prop.z > -level.z + 50 then
            level.props_layer:Remove(prop)
        end
        prop.z = prop.z + dt * level.speed * 300
    end)
    local
    function rotate()
        prop:Tween{
            angle = prop.angle + (math.random(2) == 1 and set.angle2 or -set.angle2),
            time = math.random() * 1 + 0.5,
            delay = math.random() * 2 + 1,
            action = rotate
        }
    end
    if set.angle2 ~= 0 then
        rotate()
    end
    level.props_layer:Insert(prop)
end

local
function phase_props(level, pset)
    --coroutine.yield(0.5)
    local set = prop_sets[pset or math.random(#prop_sets)]
    for i = 1, math.random(set.num_objs[2] - set.num_objs[1] + 1) + set.num_objs[1] - 1 do
        add_prop(set, level)
        coroutine.yield(math.random() * (set.delay[2] - set.delay[1]) + set.delay[1])
    end
    coroutine.yield(math.random() * 4 + 5)
end

local
function phase_barriers(level)
    level.target_lane = math.floor(level.num_lanes / 2)
    for i = 1, 20 do
        if level:num_paths() == 1 then
            level.max_paths = 1
            level.target_lane = nil
            for i = 1, math.random(10) + 5 do
                local row = level.back_row
                add_barrier(level, i)
                while level.back_row == row do
                    coroutine.yield(0.5)
                end
                if level.portal_approaching then
                    break
                end
            end
            level.max_paths = level.stage.max_paths
            coroutine.yield(5)
            break
        end
        coroutine.yield(0.5)
        if level.portal_approaching then
            break
        end
    end
    level.target_lane = nil
end

local
function phase_scans(level)
    for i = 1, math.random(level.stage.max_scans) do
        if not level.portal_approaching then
            make_hscan(level)
        end
        -- wait a while
        coroutine.yield(math.random() * 1 + 0.3)
    end
end

local
function phase_random_collapsing(level)
    level.all_collapsing = true
    coroutine.yield(math.random() * 8 + 4)
    level.all_collapsing = false
    coroutine.yield(math.random() * 2 + 1)
end

local
function phase_long_gaps(level)
    level.long_gaps = true
    coroutine.yield(math.random() * 8 + 6)
    level.long_gaps = false
    coroutine.yield(math.random() * 2 + 1)
end

local
function phase_spin(level)
    level.spin_platforms = true
    coroutine.yield(math.random() * 8 + 6)
    level.spin_platforms = false
    coroutine.yield(math.random() * 2 + 1)
end

local
function phase_pattern(level)
    --[[
    level.target_lane = 1
    for i = 1, 20 do
        if level:num_paths() == 1 and level:get_platform_under(1, 100) then
            level.target_lane = nil
            level.pattern = level.patterns[math.random(#level.patterns)]
            level.pattern_pos = 1
            repeat
                coroutine.yield(0.5)
            until level.pattern == nil
            break
        end
        coroutine.yield(0.5)
        if level.portal_approaching then
            level.target_lane = nil
            break
        end
    end
    ]]
end

local
function phase_gap(level)
    coroutine.yield(math.random() * 5 + 4)
end

local phase_map = {
    random_collapsing = phase_random_collapsing,
    long_gaps = phase_long_gaps,
    spin = phase_spin,
    scans = phase_scans,
    props1 = function(level) phase_props(level, 1) end,
    props2 = function(level) phase_props(level, 2) end,
    props3 = function(level) phase_props(level, 3) end,
    pattern = phase_pattern,
    gap = phase_gap
}

function setup_phases(level)
    return
    --[[
    level.solids_layer:Action(coroutine.wrap(function(dt)
        local phases = {}
        local count = 0
        for _, phase in ipairs(level.stage.phases) do
            table.insert(phases, phase_map[phase])
            count = count + 1
        end
        if count == 0 then
            return true
        end
        local prev_phase = nil
        while true do
            local phase
            local limit = 10
            repeat
                phase = phases[math.random(#phases)]
                limit = limit - 1
            until phase ~= prev_phase or limit == 0
            phase(level)
            prev_phase = phase
        end
        return true
    end))
    ]]
end
